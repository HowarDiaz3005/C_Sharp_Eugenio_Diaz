﻿using BinaryAdapters;

string filePath = "people.bin";

IPersonRepository personRepository = new PersonBinaryRepository(filePath);

// Agregar algunas personas
personRepository.AddPerson(new Person { Name = "Juan", Age = 17, Height = 170 });
personRepository.AddPerson(new Person { Name = "Maria", Age = 18, Height = 160 });




Console.WriteLine($"Datos de personas guardadas en {filePath}");
foreach (Person person in personRepository.GetAll())
    Console.WriteLine($"Id: {person.Id}, Nombre: {person.Name}, Edad: {person.Age}, Estatura: {person.Height}");
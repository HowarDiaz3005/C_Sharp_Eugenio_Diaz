﻿// Crear una instancia del lector original
using Adapter;

ILectorDatos lectorOriginal = new LectorDatos();  

// Utlizar el cliente con el lector original
Cliente cliente1 = new Cliente (lectorOriginal);
cliente1.RealizarOperacionDeLectura();

// Crear un adaptador para StreamReader
StreamReader streamReader = new StreamReader("archivo.txt");
ILectorDatos adaptadorStreamReader = new AdaptadorStreamReader(streamReader);

// Utilizar el cliente con el adaptador para StreamReader
Cliente cliente2 = new Cliente(adaptadorStreamReader);
cliente2.RealizarOperacionDeLectura ();




﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter
{
    public class Cliente
    {
        private ILectorDatos _lectorDatos;

        public Cliente(ILectorDatos lectorDatos)
        {
            _lectorDatos = lectorDatos;
        }

        public void RealizarOperacionDeLectura()
        {
            string datos = _lectorDatos.leer();
            Console.WriteLine("Datos leidos: " + datos);
        }
    }
}

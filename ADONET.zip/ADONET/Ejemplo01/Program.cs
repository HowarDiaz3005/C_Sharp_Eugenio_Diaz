﻿using Ejemplo01;
using System.Configuration;

string sqlServerConnectionString = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

IRepository<Inventory> repository = new CustomerRepository(sqlServerConnectionString);

var sqlServerCustomers = repository.GetAll();
Console.WriteLine("Clientes de SQL Server");
foreach (var inventory in sqlServerCustomers)
Console.WriteLine($"ID: {inventory.Id}, MakeId: {inventory.MakeId}, Color: {inventory.Color}, PetName:{inventory.PetName}");
﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Agenda
{
    public class ContactoRepository : IRepository<Contacto>
    {
        private readonly string _connectionString;

        public ContactoRepository(string connnectionString)
        {
            _connectionString = connnectionString;
        }

        // =============================================================================
        // Metodo para el IEnumerable 

        public IEnumerable<Contacto> GetAll()
        {
           List<Contacto> contactos = new List<Contacto>();
            string queryString = "SELECT Id, Nombre, Apellido, FechaNacimiento, Telefono, Email  FROM Contactos";
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(queryString, connection);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            contactos.Add(new Contacto()
                            {
                                Id = reader.GetInt32(0),
                                Nombre = reader.GetString(1),
                                Apellido = reader.GetString(2),
                                FechaNacimiento = reader.GetDateTime(3),
                                Telefono = reader.GetInt32(4),
                                Email = reader.GetString(5),

                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception($"Error al obtener contactos de la base de datos {ex.Message}");
            }
            return contactos;
        }

        // =============================================================================
        // Metodo para Contacto referente al id

        public Contacto GetValue(int id)
        {
            string queryString = "SELECT Id, Nombre, Apellido, FechaNacimiento, Telefono, Email  FROM Contactos WHERE Id = @id";
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(queryString, connection);
                    cmd.Parameters.AddWithValue("id", id);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if(reader.Read())
                    { 
                        Contacto contacto = new Contacto
                        {
                            Id = reader.GetInt32(0),
                            Nombre = reader.GetString(1),
                            Apellido = reader.GetString(2),
                            FechaNacimiento = reader.GetDateTime(3),
                            Telefono = reader.GetInt32(4),
                            Email = reader.GetString(5),

                        };
                        return contacto;
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception($"Error al obtener contacto de la base de datos{ex.Message}");
            }
            return null;
        }

        // =============================================================================
        // Metodo para delete 

        public void Delete(int id)
        {
            string queryString = "DELETE FROM Contactos WHERE Id = @id";
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(queryString, connection);
                    command.Parameters.AddWithValue("@id", id);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {

                throw new($"Error al eliminar contacto de la base de datos{ex.Message}");
            }
        }

        // =============================================================================

        public void Insert(Contacto contacto)
        {
            string queryString = "INSERT INTO Contactos(Nombre, Apellid";

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(queryString , connection);

                    command.Parameters.AddWithValue("@Id", contacto.Id);
                    command.Parameters.AddWithValue("@Id", contacto.Nombre);
                    command.Parameters.AddWithValue("@Id", contacto.Apellido);
                    command.Parameters.AddWithValue("@Id", contacto.FechaNacimiento);
                    command.Parameters.AddWithValue("@Id", contacto.Telefono);
                    command.Parameters.AddWithValue("@Id", contacto.Email);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {

                throw new Exception("Error cuando se esta intentando insertar record from ");
            }  
        }

        // =============================================================================

        public void Update(Contacto contacto)
        {
            throw new NotImplementedException();
        }
    }
}

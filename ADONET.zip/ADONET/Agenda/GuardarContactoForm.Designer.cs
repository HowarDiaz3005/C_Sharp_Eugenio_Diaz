﻿namespace Agenda
{
    partial class GuardarContactoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Nombre = new Label();
            txtNombres = new TextBox();
            Apellido = new Label();
            label3 = new Label();
            txtApellidos = new TextBox();
            dtpFechaNacimiento = new DateTimePicker();
            Telefono = new Label();
            txtTelefono = new TextBox();
            Correo = new Label();
            btnGuardar = new Button();
            txtEmail = new TextBox();
            SuspendLayout();
            // 
            // Nombre
            // 
            Nombre.AutoSize = true;
            Nombre.Location = new Point(7, 36);
            Nombre.Name = "Nombre";
            Nombre.Size = new Size(78, 15);
            Nombre.TabIndex = 0;
            Nombre.Text = "FIRST NAME :";
            // 
            // txtNombres
            // 
            txtNombres.Location = new Point(85, 28);
            txtNombres.Name = "txtNombres";
            txtNombres.Size = new Size(284, 23);
            txtNombres.TabIndex = 1;
            txtNombres.TextChanged += textBox1_TextChanged;
            // 
            // Apellido
            // 
            Apellido.AutoSize = true;
            Apellido.Location = new Point(7, 107);
            Apellido.Name = "Apellido";
            Apellido.Size = new Size(76, 15);
            Apellido.TabIndex = 2;
            Apellido.Text = "LAST NAME :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 201);
            label3.Name = "label3";
            label3.Size = new Size(141, 15);
            label3.TabIndex = 3;
            label3.Text = "FECHA DE NACIMIENTO :";
            label3.Click += label3_Click;
            // 
            // txtApellidos
            // 
            txtApellidos.Location = new Point(85, 104);
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(284, 23);
            txtApellidos.TabIndex = 4;
            // 
            // dtpFechaNacimiento
            // 
            dtpFechaNacimiento.Location = new Point(147, 195);
            dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            dtpFechaNacimiento.Size = new Size(222, 23);
            dtpFechaNacimiento.TabIndex = 5;
            // 
            // Telefono
            // 
            Telefono.AutoSize = true;
            Telefono.Location = new Point(7, 277);
            Telefono.Name = "Telefono";
            Telefono.Size = new Size(53, 15);
            Telefono.TabIndex = 6;
            Telefono.Text = "PHONE :";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(85, 269);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(284, 23);
            txtTelefono.TabIndex = 7;
            // 
            // Correo
            // 
            Correo.AutoSize = true;
            Correo.Location = new Point(21, 352);
            Correo.Name = "Correo";
            Correo.Size = new Size(47, 15);
            Correo.TabIndex = 8;
            Correo.Text = "EMAIL :";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(150, 404);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 9;
            btnGuardar.Text = "SAVE";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += button1_Click;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(85, 349);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(284, 23);
            txtEmail.TabIndex = 10;
            // 
            // GuardarContactoForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(381, 452);
            Controls.Add(txtEmail);
            Controls.Add(btnGuardar);
            Controls.Add(Correo);
            Controls.Add(txtTelefono);
            Controls.Add(Telefono);
            Controls.Add(dtpFechaNacimiento);
            Controls.Add(txtApellidos);
            Controls.Add(label3);
            Controls.Add(Apellido);
            Controls.Add(txtNombres);
            Controls.Add(Nombre);
            Name = "GuardarContactoForm";
            Text = "Guardar Contacto";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Nombre;
        private TextBox txtNombres;
        private Label Apellido;
        private Label label3;
        private TextBox txtApellidos;
        private DateTimePicker dtpFechaNacimiento;
        private Label Telefono;
        private TextBox txtTelefono;
        private Label Correo;
        private Button btnGuardar;
        private TextBox txtEmail;
    }
}
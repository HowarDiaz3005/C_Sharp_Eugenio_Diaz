﻿namespace Agenda
{
    partial class GuardarContactoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Nombre = new Label();
            textBox1 = new TextBox();
            Apellido = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            Telefono = new Label();
            textBox3 = new TextBox();
            Correo = new Label();
            button1 = new Button();
            textBox4 = new TextBox();
            SuspendLayout();
            // 
            // Nombre
            // 
            Nombre.AutoSize = true;
            Nombre.Location = new Point(7, 36);
            Nombre.Name = "Nombre";
            Nombre.Size = new Size(78, 15);
            Nombre.TabIndex = 0;
            Nombre.Text = "FIRST NAME :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(85, 28);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(284, 23);
            textBox1.TabIndex = 1;
            // 
            // Apellido
            // 
            Apellido.AutoSize = true;
            Apellido.Location = new Point(7, 107);
            Apellido.Name = "Apellido";
            Apellido.Size = new Size(76, 15);
            Apellido.TabIndex = 2;
            Apellido.Text = "LAST NAME :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 201);
            label3.Name = "label3";
            label3.Size = new Size(141, 15);
            label3.TabIndex = 3;
            label3.Text = "FECHA DE NACIMIENTO :";
            label3.Click += label3_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(85, 104);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(284, 23);
            textBox2.TabIndex = 4;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(147, 195);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(222, 23);
            dateTimePicker1.TabIndex = 5;
            // 
            // Telefono
            // 
            Telefono.AutoSize = true;
            Telefono.Location = new Point(7, 277);
            Telefono.Name = "Telefono";
            Telefono.Size = new Size(53, 15);
            Telefono.TabIndex = 6;
            Telefono.Text = "PHONE :";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(85, 269);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(284, 23);
            textBox3.TabIndex = 7;
            // 
            // Correo
            // 
            Correo.AutoSize = true;
            Correo.Location = new Point(21, 352);
            Correo.Name = "Correo";
            Correo.Size = new Size(47, 15);
            Correo.TabIndex = 8;
            Correo.Text = "EMAIL :";
            // 
            // button1
            // 
            button1.Location = new Point(150, 404);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 9;
            button1.Text = "SAVE";
            button1.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(85, 349);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(284, 23);
            textBox4.TabIndex = 10;
            // 
            // GuardarContactoForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(381, 452);
            Controls.Add(textBox4);
            Controls.Add(button1);
            Controls.Add(Correo);
            Controls.Add(textBox3);
            Controls.Add(Telefono);
            Controls.Add(dateTimePicker1);
            Controls.Add(textBox2);
            Controls.Add(label3);
            Controls.Add(Apellido);
            Controls.Add(textBox1);
            Controls.Add(Nombre);
            Name = "GuardarContactoForm";
            Text = "Guardar Contacto";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Nombre;
        private TextBox textBox1;
        private Label Apellido;
        private Label label3;
        private TextBox textBox2;
        private DateTimePicker dateTimePicker1;
        private Label Telefono;
        private TextBox textBox3;
        private Label Correo;
        private Button button1;
        private TextBox textBox4;
    }
}
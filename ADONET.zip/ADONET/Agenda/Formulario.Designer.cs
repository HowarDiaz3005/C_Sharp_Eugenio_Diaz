﻿namespace Agenda
{
    partial class Formulario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnNuevo = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            dguContactos = new DataGridView();
            btnActualizar = new Button();
            ((System.ComponentModel.ISupportInitialize)dguContactos).BeginInit();
            SuspendLayout();
            // 
            // btnNuevo
            // 
            btnNuevo.Location = new Point(22, 60);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new Size(113, 77);
            btnNuevo.TabIndex = 0;
            btnNuevo.Text = "NEW";
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += button1_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(143, 60);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(113, 77);
            btnEditar.TabIndex = 1;
            btnEditar.Text = "EDIT";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(270, 60);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(113, 77);
            btnEliminar.TabIndex = 2;
            btnEliminar.Text = "DELETE";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // dguContactos
            // 
            dguContactos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dguContactos.Location = new Point(3, 161);
            dguContactos.Name = "dguContactos";
            dguContactos.ReadOnly = true;
            dguContactos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dguContactos.Size = new Size(796, 277);
            dguContactos.TabIndex = 3;
            // 
            // btnActualizar
            // 
            btnActualizar.Location = new Point(627, 57);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(113, 77);
            btnActualizar.TabIndex = 4;
            btnActualizar.Text = "REFRESH";
            btnActualizar.UseVisualStyleBackColor = true;
            btnActualizar.Click += btnActualizar_Click;
            // 
            // Formulario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(btnActualizar);
            Controls.Add(dguContactos);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnNuevo);
            Name = "Formulario";
            Text = "Formulario";
            Load += Formulario_Load;
            ((System.ComponentModel.ISupportInitialize)dguContactos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnNuevo;
        private Button btnEditar;
        private Button btnEliminar;
        private DataGridView dguContactos;
        private Button btnActualizar;
    }
}
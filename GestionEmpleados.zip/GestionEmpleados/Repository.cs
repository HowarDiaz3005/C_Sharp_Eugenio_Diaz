﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEmpleados
{
    public class Repository
    {
        public string nombreDelEmpleado1 {  get; set; }
        public string nombreDelEmpleado2 { get; set; }
        public string nombreDelEmpleado3 { get; set; }
        public string nombreDelEmpleado4 { get; set; }
        public int edadDelEmpleado1 { get; set; }
        public int edadDelEmpleado2 { get; set; }
        public int edadDelEmpleado3 { get; set; }
        public int edadDelEmpleado4 { get; set; }
        public decimal salarioDeLosEmpleados1 { get; set; }
        public decimal salarioDeLosEmpleados2 { get; set; }
        public decimal salarioDeLosEmpleados3 { get; set; }
        public decimal salarioDeLosEmpleados4 { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEmpleados
{
    public partial class Base : Form
    {
        public Base()
        {
            InitializeComponent();
        }

        private void Base_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtNombreClient1_TextChanged(object sender, EventArgs e)
        {
            string nameC1 = txtNombreClient1.Text;
        }

        private void txtNombreClient2_TextChanged(object sender, EventArgs e)
        {
            string nameC2 = txtNombreClient2.Text;
        }

        private void txtNombreClient3_TextChanged(object sender, EventArgs e)
        {
            string nameC3 = txtNombreClient3.Text;
        }

        private void txtNombreClient4_TextChanged(object sender, EventArgs e)
        {
            string nameC4 = txtNombreClient4.Text;
        }

        private void txtEdadClient1_TextChanged(object sender, EventArgs e)
        {
            int edadC1 = Convert.ToInt32(txtEdadClient1.Text);
        }

        private void txtEdadClient2_TextChanged(object sender, EventArgs e)
        {
            int edadC2 = Convert.ToInt32(txtEdadClient2.Text);
        }

        private void txtEdadClient3_TextChanged(object sender, EventArgs e)
        {
            int edadC3 = Convert.ToInt32(txtEdadClient3.Text);
        }

        private void txtEdadClient4_TextChanged(object sender, EventArgs e)
        {
            int edadC4 = Convert.ToInt32(txtEdadClient4.Text);
        }

        private void txtSalarioClient1_TextChanged(object sender, EventArgs e)
        {
            decimal salarioC1 = Convert.ToDecimal(txtSalarioClient1.Text);
            decimal CalcutSal1 = (salarioC1 / 30);
        }

        private void txtSalarioClient2_TextChanged(object sender, EventArgs e)
        {
            decimal salarioC2 = Convert.ToDecimal(txtSalarioClient2.Text);
            decimal CalcutSal2 = (salarioC2 / 30);
        }

        private void txtSalarioClient3_TextChanged(object sender, EventArgs e)
        {
            decimal salarioC3 = Convert.ToDecimal(txtSalarioClient3.Text);
            decimal CalcutSal3 = (salarioC3 / 30);
        }

        private void txtSalarioClient4_TextChanged(object sender, EventArgs e)
        {
            decimal salarioC4 = Convert.ToDecimal(txtSalarioClient4.Text);
            decimal CalcutSal4 = (salarioC4 / 30);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            MostrarDatos mostradorDatos = new MostrarDatos();
            mostradorDatos.Show();
        }
    }
}

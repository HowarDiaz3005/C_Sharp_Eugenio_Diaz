﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEmpleados
{
    public partial class MostrarDatos : Form
    {
        public MostrarDatos(string nombre, int edad, decimal Salario)
        {
            InitializeComponent();

        }

        private void MostrarDatos_Load(object sender, EventArgs e)
        {

        }
    }
}

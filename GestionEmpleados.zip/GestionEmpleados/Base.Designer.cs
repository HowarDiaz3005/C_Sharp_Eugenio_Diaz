﻿namespace GestionEmpleados
{
    partial class Base
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombreClient1 = new Label();
            lblEdad = new Label();
            txtNombreClient1 = new TextBox();
            txtEdadClient1 = new TextBox();
            txtEdadClient2 = new TextBox();
            txtNombreClient2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtEdadClient3 = new TextBox();
            txtNombreClient3 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            txtEdadClient4 = new TextBox();
            txtNombreClient4 = new TextBox();
            label5 = new Label();
            label6 = new Label();
            lblTitulo = new Label();
            lblTituloClient1 = new Label();
            lblTituloClient2 = new Label();
            lblTituloClient4 = new Label();
            lblTituloClient3 = new Label();
            lblSalarioClient1 = new Label();
            lblSalarioClient2 = new Label();
            lblSalarioClient3 = new Label();
            lblSalarioClient4 = new Label();
            txtSalarioClient1 = new TextBox();
            txtSalarioClient2 = new TextBox();
            txtSalarioClient4 = new TextBox();
            txtSalarioClient3 = new TextBox();
            btnGuardar = new Button();
            btnSalir = new Button();
            SuspendLayout();
            // 
            // lblNombreClient1
            // 
            lblNombreClient1.AutoSize = true;
            lblNombreClient1.Location = new Point(27, 99);
            lblNombreClient1.Name = "lblNombreClient1";
            lblNombreClient1.Size = new Size(57, 15);
            lblNombreClient1.TabIndex = 0;
            lblNombreClient1.Text = "Nombre :";
            // 
            // lblEdad
            // 
            lblEdad.AutoSize = true;
            lblEdad.Location = new Point(32, 171);
            lblEdad.Name = "lblEdad";
            lblEdad.Size = new Size(39, 15);
            lblEdad.TabIndex = 1;
            lblEdad.Text = "Edad :";
            // 
            // txtNombreClient1
            // 
            txtNombreClient1.Location = new Point(27, 117);
            txtNombreClient1.Name = "txtNombreClient1";
            txtNombreClient1.Size = new Size(183, 23);
            txtNombreClient1.TabIndex = 2;
            txtNombreClient1.TextChanged += txtNombreClient1_TextChanged;
            // 
            // txtEdadClient1
            // 
            txtEdadClient1.Location = new Point(27, 189);
            txtEdadClient1.Name = "txtEdadClient1";
            txtEdadClient1.Size = new Size(183, 23);
            txtEdadClient1.TabIndex = 3;
            txtEdadClient1.TextChanged += txtEdadClient1_TextChanged;
            // 
            // txtEdadClient2
            // 
            txtEdadClient2.Location = new Point(247, 189);
            txtEdadClient2.Name = "txtEdadClient2";
            txtEdadClient2.Size = new Size(183, 23);
            txtEdadClient2.TabIndex = 7;
            txtEdadClient2.TextChanged += txtEdadClient2_TextChanged;
            // 
            // txtNombreClient2
            // 
            txtNombreClient2.Location = new Point(247, 117);
            txtNombreClient2.Name = "txtNombreClient2";
            txtNombreClient2.Size = new Size(183, 23);
            txtNombreClient2.TabIndex = 6;
            txtNombreClient2.TextChanged += txtNombreClient2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(252, 171);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 5;
            label1.Text = "Edad :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(247, 99);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 4;
            label2.Text = "Nombre :";
            // 
            // txtEdadClient3
            // 
            txtEdadClient3.Location = new Point(468, 189);
            txtEdadClient3.Name = "txtEdadClient3";
            txtEdadClient3.Size = new Size(183, 23);
            txtEdadClient3.TabIndex = 11;
            txtEdadClient3.TextChanged += txtEdadClient3_TextChanged;
            // 
            // txtNombreClient3
            // 
            txtNombreClient3.Location = new Point(468, 117);
            txtNombreClient3.Name = "txtNombreClient3";
            txtNombreClient3.Size = new Size(183, 23);
            txtNombreClient3.TabIndex = 10;
            txtNombreClient3.TextChanged += txtNombreClient3_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(473, 171);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 9;
            label3.Text = "Edad :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(468, 99);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 8;
            label4.Text = "Nombre :";
            // 
            // txtEdadClient4
            // 
            txtEdadClient4.Location = new Point(686, 189);
            txtEdadClient4.Name = "txtEdadClient4";
            txtEdadClient4.Size = new Size(183, 23);
            txtEdadClient4.TabIndex = 15;
            txtEdadClient4.TextChanged += txtEdadClient4_TextChanged;
            // 
            // txtNombreClient4
            // 
            txtNombreClient4.Location = new Point(686, 117);
            txtNombreClient4.Name = "txtNombreClient4";
            txtNombreClient4.Size = new Size(183, 23);
            txtNombreClient4.TabIndex = 14;
            txtNombreClient4.TextChanged += txtNombreClient4_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(691, 171);
            label5.Name = "label5";
            label5.Size = new Size(39, 15);
            label5.TabIndex = 13;
            label5.Text = "Edad :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(686, 99);
            label6.Name = "label6";
            label6.Size = new Size(57, 15);
            label6.TabIndex = 12;
            label6.Text = "Nombre :";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(308, 9);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(281, 37);
            lblTitulo.TabIndex = 16;
            lblTitulo.Text = "REGISTRO DE DATOS";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblTituloClient1
            // 
            lblTituloClient1.AutoSize = true;
            lblTituloClient1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloClient1.Location = new Point(69, 72);
            lblTituloClient1.Name = "lblTituloClient1";
            lblTituloClient1.Size = new Size(70, 17);
            lblTituloClient1.TabIndex = 17;
            lblTituloClient1.Text = "CLIENTE 1";
            // 
            // lblTituloClient2
            // 
            lblTituloClient2.AutoSize = true;
            lblTituloClient2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloClient2.Location = new Point(299, 72);
            lblTituloClient2.Name = "lblTituloClient2";
            lblTituloClient2.Size = new Size(70, 17);
            lblTituloClient2.TabIndex = 18;
            lblTituloClient2.Text = "CLIENTE 2";
            // 
            // lblTituloClient4
            // 
            lblTituloClient4.AutoSize = true;
            lblTituloClient4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloClient4.Location = new Point(740, 72);
            lblTituloClient4.Name = "lblTituloClient4";
            lblTituloClient4.Size = new Size(70, 17);
            lblTituloClient4.TabIndex = 20;
            lblTituloClient4.Text = "CLIENTE 4";
            // 
            // lblTituloClient3
            // 
            lblTituloClient3.AutoSize = true;
            lblTituloClient3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloClient3.Location = new Point(529, 72);
            lblTituloClient3.Name = "lblTituloClient3";
            lblTituloClient3.Size = new Size(70, 17);
            lblTituloClient3.TabIndex = 19;
            lblTituloClient3.Text = "CLIENTE 3";
            // 
            // lblSalarioClient1
            // 
            lblSalarioClient1.AutoSize = true;
            lblSalarioClient1.Location = new Point(32, 246);
            lblSalarioClient1.Name = "lblSalarioClient1";
            lblSalarioClient1.Size = new Size(96, 15);
            lblSalarioClient1.TabIndex = 21;
            lblSalarioClient1.Text = " Salario Mensual:";
            lblSalarioClient1.Click += label7_Click;
            // 
            // lblSalarioClient2
            // 
            lblSalarioClient2.AutoSize = true;
            lblSalarioClient2.Location = new Point(247, 246);
            lblSalarioClient2.Name = "lblSalarioClient2";
            lblSalarioClient2.Size = new Size(96, 15);
            lblSalarioClient2.TabIndex = 22;
            lblSalarioClient2.Text = " Salario Mensual:";
            // 
            // lblSalarioClient3
            // 
            lblSalarioClient3.AutoSize = true;
            lblSalarioClient3.Location = new Point(468, 246);
            lblSalarioClient3.Name = "lblSalarioClient3";
            lblSalarioClient3.Size = new Size(96, 15);
            lblSalarioClient3.TabIndex = 23;
            lblSalarioClient3.Text = " Salario Mensual:";
            // 
            // lblSalarioClient4
            // 
            lblSalarioClient4.AutoSize = true;
            lblSalarioClient4.Location = new Point(686, 246);
            lblSalarioClient4.Name = "lblSalarioClient4";
            lblSalarioClient4.Size = new Size(96, 15);
            lblSalarioClient4.TabIndex = 24;
            lblSalarioClient4.Text = " Salario Mensual:";
            // 
            // txtSalarioClient1
            // 
            txtSalarioClient1.Location = new Point(27, 264);
            txtSalarioClient1.Name = "txtSalarioClient1";
            txtSalarioClient1.Size = new Size(183, 23);
            txtSalarioClient1.TabIndex = 25;
            txtSalarioClient1.TextChanged += txtSalarioClient1_TextChanged;
            // 
            // txtSalarioClient2
            // 
            txtSalarioClient2.Location = new Point(247, 264);
            txtSalarioClient2.Name = "txtSalarioClient2";
            txtSalarioClient2.Size = new Size(183, 23);
            txtSalarioClient2.TabIndex = 26;
            txtSalarioClient2.TextChanged += txtSalarioClient2_TextChanged;
            // 
            // txtSalarioClient4
            // 
            txtSalarioClient4.Location = new Point(686, 264);
            txtSalarioClient4.Name = "txtSalarioClient4";
            txtSalarioClient4.Size = new Size(183, 23);
            txtSalarioClient4.TabIndex = 28;
            txtSalarioClient4.TextChanged += txtSalarioClient4_TextChanged;
            // 
            // txtSalarioClient3
            // 
            txtSalarioClient3.Location = new Point(468, 264);
            txtSalarioClient3.Name = "txtSalarioClient3";
            txtSalarioClient3.Size = new Size(183, 23);
            txtSalarioClient3.TabIndex = 27;
            txtSalarioClient3.TextChanged += txtSalarioClient3_TextChanged;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.MediumSpringGreen;
            btnGuardar.Location = new Point(268, 322);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(87, 24);
            btnGuardar.TabIndex = 29;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.BackColor = Color.LightSalmon;
            btnSalir.Location = new Point(512, 322);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(87, 24);
            btnSalir.TabIndex = 30;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // Base
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(881, 379);
            Controls.Add(btnSalir);
            Controls.Add(btnGuardar);
            Controls.Add(txtSalarioClient4);
            Controls.Add(txtSalarioClient3);
            Controls.Add(txtSalarioClient2);
            Controls.Add(txtSalarioClient1);
            Controls.Add(lblSalarioClient4);
            Controls.Add(lblSalarioClient3);
            Controls.Add(lblSalarioClient2);
            Controls.Add(lblSalarioClient1);
            Controls.Add(lblTituloClient4);
            Controls.Add(lblTituloClient3);
            Controls.Add(lblTituloClient2);
            Controls.Add(lblTituloClient1);
            Controls.Add(lblTitulo);
            Controls.Add(txtEdadClient4);
            Controls.Add(txtNombreClient4);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(txtEdadClient3);
            Controls.Add(txtNombreClient3);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(txtEdadClient2);
            Controls.Add(txtNombreClient2);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(txtEdadClient1);
            Controls.Add(txtNombreClient1);
            Controls.Add(lblEdad);
            Controls.Add(lblNombreClient1);
            Name = "Base";
            Text = "Base";
            Load += Base_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNombreClient1;
        private Label lblEdad;
        private TextBox txtNombreClient1;
        private TextBox txtEdadClient1;
        private TextBox txtEdadClient2;
        private TextBox txtNombreClient2;
        private TextBox lblNombreClient2;
        private Label label1;
        private Label label2;
        private TextBox txtEdadClient3;
        private TextBox txtNombreClient3;
        private TextBox textBox5;
        private TextBox lblNombreClient3;
        private Label label3;
        private Label label4;
        private TextBox txtEdadClient4;
        private TextBox txtNombreClient4;
        private TextBox textBox7;
        private TextBox lblNombreClient4;
        private Label label5;
        private Label label6;
        private Label lblTitulo;
        private Label lblTituloClient1;
        private Label lblTituloClient2;
        private Label label8;
        private Label lblTituloClient4;
        private Label lblTituloClient3;
        private Label lblSalarioClient1;
        private Label lblSalarioClient2;
        private Label lblSalarioClient3;
        private Label lblSalarioClient4;
        private TextBox txtSalarioClient1;
        private TextBox txtSalarioClient2;
        private TextBox textBox3;
        private TextBox txtSalarioClient4;
        private TextBox txtSalarioClient3;
        private Button btnGuardar;
        private Button btnSalir;
    }
}
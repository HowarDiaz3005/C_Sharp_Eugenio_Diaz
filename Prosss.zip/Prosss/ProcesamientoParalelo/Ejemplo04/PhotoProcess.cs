﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo04
{
    public class PhotoProcess
    { 
        private readonly IRepository<string> _repository;

        public PhotoProcess(IRepository<string> repository)
        {
           _repository = repository;
        }   

        public void CopyPhotosInParallels() 
        {
            List<string> photoPaths = _repository.GetAll();

            Parallel.ForEach(photoPaths, photo =>
            {
                string fileName = Path.GetFileName(photo);
                string destinationPath = Path.Combine (_repository.GetDestinationFolder(), fileName);
                _repository.Copy(photo, destinationPath);
                Console.WriteLine($"Foto copiada: {fileName} en hilo" + $"{Task.CurrentId}");
            });
        }

    }
}

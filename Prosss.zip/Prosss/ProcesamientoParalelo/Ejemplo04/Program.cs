﻿using Ejemplo04;

string sourceFolderPath = @"C:\SourceFolder";
string destinationFolderPath = @"C:\DestinationFolder";

IRepository<string> FileRepository = new FileRepository(sourceFolderPath, destinationFolderPath);
var photoProcessor = new PhotoProcess(FileRepository);

photoProcessor.CopyPhotosInParallels();


Console.WriteLine("Copia de fotos finalizada.");
Console.ReadLine();
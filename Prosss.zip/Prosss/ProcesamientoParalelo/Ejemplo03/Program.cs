﻿using Ejemplo03;

string[] names = { "Roma", "Sherly", "Jesus", "Estrella", "Axel", "Guadalupe", "Howard", "Jose", "Marcos", "Reynaldo", "Felix", "Maria"};

var repository = new StringRepository(names);
var processor = new StringProcessor(repository);

try
{

	// Filtrado secuencial
	var sequentialResult = processor.FilterStringsStartingWith('E').AsParallel();
	Console.WriteLine("\nResultado del filtrado en paralelo:");
	PrintNames(sequentialResult);

	// Filtrado paralelo
	var parallelResult = processor.FilterStringsStartingWith('E').AsParallel();
	Console.WriteLine("\nResultado del filtrado en paralelo:");
	PrintNames(ParallelResult);


}
catch (Exception ex)
{

	Console.WriteLine
}


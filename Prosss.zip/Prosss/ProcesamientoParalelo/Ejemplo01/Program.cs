﻿using System.Diagnostics;

var numeros = Enumerable.Range(1, 1000);

var sw = new Stopwatch();

sw.Start();


var numerosPares = from num in numeros.AsParallel()
                   where num % 2 == 0
                    select num;

foreach (var numero in numerosPares)
{ 
    Console.WriteLine(numero);
}

sw.Stop();
Console.WriteLine(
    $"{0} NUMEROS PARES DE {1} NUMEROS. TIEMPO {2}",
numerosPares.Count(), numeros.Count(), sw.ElapsedMilliseconds);
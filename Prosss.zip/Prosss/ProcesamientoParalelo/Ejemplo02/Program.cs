﻿using Ejemplo02;
using System.Diagnostics;

var sw = new Stopwatch();

sw.Start();

var repository = new StringRepository(1000, 10);
var procesador = new StringProcessor(repository);
var filteredStrings = procesador.FilterString();    


foreach (var item in filteredStrings)
{
    Console.WriteLine(item);
}

sw.Stop();

Console.WriteLine($"Tiempo transcurrido: {sw.ElapsedMilliseconds} ms");
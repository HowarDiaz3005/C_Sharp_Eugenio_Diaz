﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo02
{
    public class StringProcessor
    {
        private readonly IRepository1<string> _repository;  

        public StringProcessor(IRepository1<string> repository) 
        {
            _repository = repository;   
        }

        public List<string> FilterString  () =>
            _repository.GetAll ().AsParallel ().Where (s => s.Contains("W")).ToList();
    }
}

﻿namespace Ejemplo02
{
    public interface IRepository1<T>
    {
        List<T> GetAll();

        void Add( T item);
    }
}
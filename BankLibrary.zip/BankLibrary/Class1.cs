﻿namespace BankLibrary
{
    public class Class1
    {
    }
}
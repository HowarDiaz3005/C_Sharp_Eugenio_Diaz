﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankLibrary
{
    public partial class Form1 : Form
                     // BankUIForm
    {

        protected int TextBoxCount { get; set; } = 4; // numero de controles TextBox en el formulario

        // las constantes en la enumeracion especifican los indices de los controles TextBox

        public enum TextBoxIndices { Account, First, Last, Balance }

        // Constructor sin parametros


        public Form1()
        {
            InitializeComponent();
        }
        // Limpia todos los controles TextBox


        public void ClearComponent()
        {
            // itera a traves de cada Control en el formulario
            foreach (Control guiControl in Controls)
            {
                // si el Control es TextBox, lo limpia
                (guiControl as TextBox)?.Clear();
            }
        }

        // establece los valores de los controles TextBox con el arreglo string values

        public void SetTextValue(string[] values)
        {
            // determina si el arreglo string tiene la longitud correcta
            if (values.Length != TextBoxCount)
            {
                // lanza excepcion si no tiene la longitud correcta
                throw new ArgumentException(
                    $"There must be {TextBoxCount} string in the array", 
                    nameof(values));
            }

            else // set array values if array has correct length
            {
                // establece al arreglo los valores si el arreglo tiene la longitud correcta
                accountTexBox.Text = values[(int)TextBoxIndices.Account];
                firstNameTextBox.Text = values[(int)TextBoxIndices.First];
                lastNameTextBox.Text = values[(int)TextBoxIndices.Last];
                balanceTextBox.Text = values[(int)TextBoxIndices.Balance];
            }
        }

        // devuelve los valores de los controles TextBox como un arreglo string

        public string[] GetTextBoxValues() 
        {
            return new string[]

            {
                accountTexBox.Text, firstNameTextBox.Text,
                lastNameTextBox.Text, balanceTextBox.Text
            };
        }
    }
}

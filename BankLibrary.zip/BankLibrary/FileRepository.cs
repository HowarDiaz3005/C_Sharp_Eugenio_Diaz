﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class FileRepository : IFileRepository
    {

        private StreamWriter? _fileWrite; // escribe datos en el archivo de texto
        private StreamReader _fileReader; // lee datos de un archivo de texto
        private FileStream _fileStream; // mantiene la conexion con el archivo
        private string _fileName;

        public FileRepository(string fileName) 
        {
            _fileName = fileName;
        }

        public void OpenOrCreateFile()
        {
            try
            {
                // abre el archivo con acceso de escritura
                _fileStream = new FileStream(_fileName, FileMode.OpenOrCreate,
                    FileAccess.Write);
                // establece el archivo para escribir los datos
                _fileWrite = new StreamWriter(_fileStream);
            }
            catch (IOException)
            {
                throw new IOException("Error al abrir el archivo");
            }
        }

        public void OpenFile()
        {
            try
            {
                // Crea objeto FileStream para obtener acceso de lectura al archivo
                _fileStream = new FileStream(_fileName, FileMode.Open,
                    FileAccess.Read);

                // establece el archivo del que se van a leer los datos
                _fileReader = new StreamReader(_fileStream);
            }

            catch (IOException)
            {
                throw new IOException("Error al abrir el archivo");
            }
        }

        public string? ReadNextRecord()
        {
            try
            {
                return _fileReader?.ReadLine();
            }

            catch (IOException)
            {
                throw new IOException("Error al leer del archivo");
                

            }
        }

        public void ResetFilePointer()
        {
            try
            {
                _fileStream?.Seek(0, SeekOrigin.Begin);
            }
            catch (IOException)
            {
                throw new IOException("Error al restablecer el puntero del archivo");
            }
        }

        public void CloseFile()
        {
            try
            {
                _fileWrite?.Close(); // cierra StreamWrite
                _fileReader?.Close(); // cierra StreamReader
            }
            catch (IOException)
            {
                throw new IOException("No se puede cerrar el archivo");
            }
        }

        public void WriteRecordToFile(Record record)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using Reposity;
// Ruta del archivo para almacenar productos
string archivoProducto = "productos.txt";

// Crear una instancia del repositorio de productos
// utilizando el archivo

IProductoReposity productoReposity = new ProductoRepositoryArchivo(archivoProducto);

// Crear una instancia del gestor de productos 
// utilizando el repositorio

GestorProducto gestorProducto
    = new GestorProducto(productoReposity);

// Agregar algunos productos de ejemplo

gestorProducto.AgregarProducto(new Producto { Nombre = "Pan", Precio = 24m });

Console.WriteLine("Todos los productos");
foreach (var producto in gestorProducto.ObtenerTodosProductos())
    {
    Console.WriteLine($"Nombre: {producto.Nombre}," +
         $"\nPrecio: {producto.Precio}");
}
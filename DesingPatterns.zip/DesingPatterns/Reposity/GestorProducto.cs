﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reposity
{
    public class GestorProducto
    {
        private IProductoReposity _repository;


        public GestorProducto(IProductoReposity repository)
        {
            _repository = repository;
        }

        public List<Producto> ObtenerTodosProductos() 
        {
            return _repository.ObtenerTodos();
        }

        public void AgregarProducto(Producto producto)
        {
            List<Producto> productos = _repository.ObtenerTodos();
            productos.Add(producto);    
            _repository.GuardarTodos(productos);
        }
    }
}

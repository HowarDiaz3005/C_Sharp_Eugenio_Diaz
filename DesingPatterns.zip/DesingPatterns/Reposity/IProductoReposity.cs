﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reposity
{
    public interface IProductoReposity
    {
        // Repositorio de Productos 
        List<Producto> ObtenerTodos();

        void GuardarTodos(List<Producto> producto);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    public class ContextoLectorArchivo
    {
        private ILectorArchivo _lectorArchivo;

        public ContextoLectorArchivo(ILectorArchivo lectorArchivo)
        {
            _lectorArchivo = lectorArchivo;
        }   

        public void EstablecerEstrategia(ILectorArchivo lectorArchivo)
        {
            _lectorArchivo = lectorArchivo;
        }

        public string LeerArchivo(string rutaArchivo)
        {
            return _lectorArchivo.Leer(rutaArchivo);
        }
    }
}

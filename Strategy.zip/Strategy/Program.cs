﻿using Strategy;
// Crear instancias de estrategias
ILectorArchivo lectorTexto = new LectorArchivoTexto();  
ILectorArchivo lectorXML = new LectorArchivoXML();

// Crear un contexto y establecer la estrategia inicial
ContextoLectorArchivo contexto = new ContextoLectorArchivo(lectorTexto);

// Leer un archivo de texto
string contenidoTexto = contexto.LeerArchivo("archivo.txt");
Console.WriteLine("Contenido del archivo de texto");
Console.WriteLine(contenidoTexto);

// Cambiar la estrategia para leer un archivo
contexto.EstablecerEstrategia(lectorXML);

// Leer un archivo XML
string contenidoXML = contexto.LeerArchivo("archivo.xml");
Console.WriteLine("\nContenido del archivo XML : ");
Console.WriteLine(contenidoXML);
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    public class LectorArchivoTexto : ILectorArchivo
    {
        public string Leer(string rutaArchivo)
        {
            // Logica para leer un archivo de texto
            string contenido;
            using (StreamReader reader = new StreamReader(rutaArchivo)
            {
                contenido = reader.ReadToEnd();
            }
            return contenido;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    public class LectorArchivoXML : ILectorArchivo
    {
        // Logica para leer un archivo XML
        string contenido;
        using (StreamReader reader = new StreamReader(rutaArchivo))
        {
          contenido = reader.ReadToEnd(); // Por simplicidad, suponmgamos que leemos
                                         // todo el contenido del arcihov XML
                                        // como una cadena
        }
        reutrn contenido;
    }
}

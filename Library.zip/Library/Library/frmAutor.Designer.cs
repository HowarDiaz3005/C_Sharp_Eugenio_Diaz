﻿namespace Library
{
    partial class frmAutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblName = new Label();
            txtNombre = new TextBox();
            btnAgregar = new Button();
            btnActualizar = new Button();
            btnEliminar = new Button();
            btnBuscar = new Button();
            dataGridView1 = new DataGridView();
            AutorDelLibro = new DataGridViewTextBoxColumn();
            nombreDelLibro01 = new DataGridViewTextBoxColumn();
            btnCerrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblName.Location = new Point(69, 60);
            lblName.Name = "lblName";
            lblName.Size = new Size(71, 21);
            lblName.TabIndex = 0;
            lblName.Text = "Nombre:";
            // 
            // txtNombre
            // 
            txtNombre.BorderStyle = BorderStyle.None;
            txtNombre.Location = new Point(146, 58);
            txtNombre.Multiline = true;
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(200, 33);
            txtNombre.TabIndex = 1;
            txtNombre.TextChanged += txtNombre_TextChanged;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(69, 141);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(91, 36);
            btnAgregar.TabIndex = 2;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.Location = new Point(183, 141);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(91, 36);
            btnActualizar.TabIndex = 3;
            btnActualizar.Text = "Actualizar";
            btnActualizar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(298, 141);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(91, 36);
            btnEliminar.TabIndex = 4;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(409, 141);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(91, 36);
            btnBuscar.TabIndex = 5;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { AutorDelLibro, nombreDelLibro01 });
            dataGridView1.Location = new Point(37, 205);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(494, 202);
            dataGridView1.TabIndex = 6;
            // 
            // AutorDelLibro
            // 
            AutorDelLibro.HeaderText = "Autor";
            AutorDelLibro.Name = "AutorDelLibro";
            AutorDelLibro.ReadOnly = true;
            // 
            // nombreDelLibro01
            // 
            nombreDelLibro01.HeaderText = "Nombre del Libro";
            nombreDelLibro01.Name = "nombreDelLibro01";
            nombreDelLibro01.ReadOnly = true;
            // 
            // btnCerrar
            // 
            btnCerrar.Location = new Point(540, 285);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(91, 36);
            btnCerrar.TabIndex = 7;
            btnCerrar.Text = "Cerrar";
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // frmAutor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(643, 450);
            Controls.Add(btnCerrar);
            Controls.Add(dataGridView1);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnActualizar);
            Controls.Add(btnAgregar);
            Controls.Add(txtNombre);
            Controls.Add(lblName);
            Name = "frmAutor";
            Text = "frmAutor";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private TextBox txtNombre;
        private Button btnAgregar;
        private Button btnActualizar;
        private Button btnEliminar;
        private Button btnBuscar;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn AutorDelLibro;
        private DataGridViewTextBoxColumn nombreDelLibro01;
        private Button btnCerrar;
    }
}